import { fetchJSON } from "../include/fetchJSON.js";
export function fetchGeoCoord(query) {
    const searchURL = new URL("https://geocode.maps.co/search");
    searchURL.searchParams.append("q", query);
    return fetchJSON(searchURL.toString()).then(json => Array.isArray(json) && json.length > 0
        ? Promise.resolve({ lat: Number.parseFloat(json[0].lat), lon: Number.parseFloat(json[0].lon) })
        : Promise.reject(new Error("No results found for query.")));
}
//# sourceMappingURL=fetchGeoCoord.js.map