export function fetchCurrentTemperature(coords) {
    // TODO
    return new Promise(res => res({ time: [], temperature_2m: [] }));
}
//# sourceMappingURL=fetchCurrentTemperature.js.map