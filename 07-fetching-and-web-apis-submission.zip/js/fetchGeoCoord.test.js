import assert from "assert";
import { fetchGeoCoord } from "./fetchGeoCoord.js";
function resolveCallbackTests(result, latitude, longitude) {
    assert(typeof result === "object");
    assert(typeof result.lat === "number");
    assert(typeof result.lon === "number");
    assert(Object.keys(result).length === 2);
    assert(result.lat === latitude);
    assert(result.lon === longitude);
}
describe("fetchGeoCoord", () => {
    it("follows type specification", () => {
        const promise = fetchGeoCoord("University of Massachusetts Amherst");
        return promise.then(result => {
            assert(typeof result === "object"); //  Assert the result is an object
            assert(typeof result.lon === "number"); // Assert that the lon value is a number
            assert(typeof result.lat === "number"); // Assert that the lat value is a number
            assert(Object.keys(result).length === 2); // Assert there are only two keys in the object
        });
    });
    it("correctly rejects to an Error when query is empty string", () => {
        const promise = fetchGeoCoord("");
        return promise.catch(result => {
            assert(result instanceof Error);
            assert(result.message === "No results found for query.");
        });
    });
    it("correctly rejects to an Error when query does not return any results", () => {
        const promise = fetchGeoCoord("@#(%^@#(*%^#");
        return promise.catch(result => {
            assert(result instanceof Error);
            assert(result.message === "No results found for query.");
        });
    });
    it("correctly returns the latitude and longitude for a query with exactly one result", () => {
        const promise = fetchGeoCoord("University of Massachusetts Amherst");
        return promise.then(result => resolveCallbackTests(result, 42.3869382, -72.52991477067445));
    });
    it("correctly returns the first latitude and longitude for a query with multiple results", () => {
        const promise = fetchGeoCoord("ohio mcdonalds");
        return promise.then(result => resolveCallbackTests(result, 41.64239815, -81.3758945488883));
    });
});
//# sourceMappingURL=fetchGeoCoord.test.js.map