import { fetchJSON } from "../include/fetchJSON.js";

export interface GeoCoord {
  lat: number;
  lon: number;
}

export function fetchGeoCoord(query: string): Promise<GeoCoord> {
  const searchURL = new URL("https://geocode.maps.co/search");
  searchURL.searchParams.append("q", query);
  return fetchJSON(searchURL.toString()).then(json =>
    Array.isArray(json) && json.length > 0
      ? Promise.resolve({ lat: Number.parseFloat(json[0].lat), lon: Number.parseFloat(json[0].lon) })
      : Promise.reject(new Error("No results found for query."))
  );
}
