import { fetchJSON } from "../include/fetchJSON.js";

export function fetchUniversities(query: string): Promise<string[]> {
  // TODO
  return new Promise(res => res([]));
}
